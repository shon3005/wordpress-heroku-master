<?php
load_theme_textdomain( 'grandblog-translation', get_template_directory().'/languages' );
?>