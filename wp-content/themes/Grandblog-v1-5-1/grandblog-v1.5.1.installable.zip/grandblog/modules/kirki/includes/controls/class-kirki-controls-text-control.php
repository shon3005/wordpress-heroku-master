<?php
/**
 * textarea Customizer Control.
 *
 * @package     Kirki
 * @subpackage  Controls
 * @copyright   Copyright (c) 2015, Aristeides Stathopoulos
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Kirki_Controls_Text_Control' ) ) {
	/**
	 * Create a simple text control
	 */
	class Kirki_Controls_Text_Control extends Kirki_Customize_Control {

		public $type = 'kirki-text';

		protected function content_template() { ?>
			<# if ( data.help ) { #>
				<a href="#" class="tooltip hint--left" data-hint="{{ data.help }}"><span class='dashicons dashicons-info'></span></a>
			<# } #>
			<label>
				<# if ( data.label ) { #>
					<span class="customize-control-title">{{{ data.label }}}</span>
				<# } #>
				<# if ( data.description ) { #>
					<span class="description customize-control-description">{{{ data.description }}}</span>
				<# } #>
				<div class="customize-control-content">
					<input type="text" value="{{ data.value }}" {{{ data.link }}} />
				</div>
			</label>
			<?php
		}

	}
}
