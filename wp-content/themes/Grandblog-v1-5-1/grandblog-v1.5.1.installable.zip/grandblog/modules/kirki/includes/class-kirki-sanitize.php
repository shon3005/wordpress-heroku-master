<?php

if ( ! class_exists( 'Kirki_Sanitize' ) ) {
	class Kirki_Sanitize extends Kirki_Customizer {}
}
